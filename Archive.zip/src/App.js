import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Cartlist from './Components/Cartlist'
import CartAdd from './Components/CartAdd'
import Webmain from './Components/Webmain'

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
         <Webmain/>
        </header>
      </div>
    );
  }
}

export default App;
