import React, { Component } from "react";
import Cartlist from './Cartlist'
import CartAdd from './CartAdd'
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect,
  withRouter
} from "react-router-dom";


function AuthExample() {
  return (
    <Router>
      <div>
        
        <ul>
          <li>
            <Link to="/public">Cart List</Link>
          </li>
          <li>
            <Link to="/public2">Add Item</Link>
          </li>
        </ul>
        <Route path="/public" component={Public} />
        
        <Route path = "/public2" component ={Public2}/>
      </div>
    </Router>
  );
}



function Public() {
  return <Cartlist/>;
}
function Public2() {
  return <CartAdd/>;
}
export default AuthExample;