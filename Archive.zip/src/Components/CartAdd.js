

import React, { Component } from 'react';
import axios from 'axios';
 class PersonInput extends Component{
state ={
    name:'',
    description: '',
    price: '',
    amount: ''
};

handleChange2(description){
    this.setState({description});
}
handleChange3(price){
    this.setState({price});
}
handleChange4(amount){
    this.setState({amount});
}
handleSubmit = event =>{
event.preventDefault();
alert("name: " + this.state.name + " des: " + this.state.description + " price: " + this.state.price);
const user  ={
    name: this.state.name,
    descripton: this.state.description,
    price: parseInt(this.state.price),
    amount: parseInt(this.state.amount)
};

const obj  ={
    name: "",
    descripton: "",
    price: 0,
    amount: 0
};
console.log(user);

axios.post('http://localhost:5555/item/add', {name: this.state.name, description:this.state.description,price: parseInt(this.state.price),amount:parseInt(this.state.amount)})
.then(res => {
   // name: res.data;
    console.log(res.data);
})
}

render(){
    return(
        <div>
        <form onSubmit ={this.handleSubmit}>
           
            <label>
            Item Name:
            <input type ="text" name = "name" onChange={e => {this.setState({name: e.target.value})}}/>
            </label>
            <label>
            Descripton:
            <input type ="text" name = "description" onChange={e => this.handleChange2(e.target.value)}/>
            </label>
            <label>
            Price:
            <input type ="text" name = "price" onChange={e => this.handleChange3(e.target.value)}/>
            </label>
            <label>
            Amount:
            <input type ="text" name = "amount" onChange={e => this.handleChange4(e.target.value)}/>
            </label>
            <button type ="submit">Add</button>
            </form>

        </div>
            
    )
}
}
export default PersonInput;