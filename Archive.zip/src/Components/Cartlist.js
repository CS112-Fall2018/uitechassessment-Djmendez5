import React, { Component } from 'react';
import axios from 'axios';
 class Cartlist extends Component{
state ={
    item:[]
};
componentDidMount(){
    axios.get('http://localhost:5555/list').then(res => {
        console.log(res);
        this.setState({item: res.data});
    });

}
render(){
    return(
        <ul>
            {this.state.item.map(cart => <li key ={cart.id}>{"Name:"}{cart.name}{" | Description: "}{cart.description}{" | Price: "}{cart.price}{" | amount: "}{cart.amount}</li>)}
        </ul>
    )
}
}
export default Cartlist;